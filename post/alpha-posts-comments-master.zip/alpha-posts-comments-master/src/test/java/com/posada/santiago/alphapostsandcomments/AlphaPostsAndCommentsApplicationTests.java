package com.posada.santiago.alphapostsandcomments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlphaPostsAndCommentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
