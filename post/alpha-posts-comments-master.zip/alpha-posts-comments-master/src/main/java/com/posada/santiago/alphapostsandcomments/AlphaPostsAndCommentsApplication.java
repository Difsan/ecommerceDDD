package com.posada.santiago.alphapostsandcomments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlphaPostsAndCommentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlphaPostsAndCommentsApplication.class, args);
	}

}
